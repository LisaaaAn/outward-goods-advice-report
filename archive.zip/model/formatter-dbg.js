sap.ui.define([], () => {
	"use strict";
	return {};
});