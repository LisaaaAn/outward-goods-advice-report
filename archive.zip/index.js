sap.ui.define(["sap/ui/core/ComponentContainer"],e=>{"use strict";new e({name:"ui5.ogarpt",settings:{id:"ogarpt"},async:true}).placeAt("content")});
//# sourceMappingURL=index.js.map