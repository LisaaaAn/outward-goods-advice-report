sap.ui.define([
   "ui5/ogarpt/controller/BaseController"
], (BaseController) => {
   "use strict";
   return BaseController.extend("ui5.ogarpt.controller.App", {});
});