sap.ui.define(["ui5/ogarpt/controller/BaseController"],function(e){"use strict";return e.extend("ui5.ogarpt.controller.formSections.SectionB",{})});
//# sourceMappingURL=SectionB.controller.js.map