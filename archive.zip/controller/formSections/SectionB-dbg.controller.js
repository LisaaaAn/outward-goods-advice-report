sap.ui.define([
    "ui5/ogarpt/controller/BaseController"
], function (BaseController) {
    "use strict";
    return BaseController.extend("ui5.ogarpt.controller.formSections.SectionB", {
    });
});