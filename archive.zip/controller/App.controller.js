sap.ui.define(["ui5/ogarpt/controller/BaseController"],r=>{"use strict";return r.extend("ui5.ogarpt.controller.App",{})});
//# sourceMappingURL=App.controller.js.map