sap.ui.define(["ui5/ogarpt/localService/mockserver"],function(e){"use strict";e.init();sap.ui.require(["sap/ui/core/ComponentSupport"])});
//# sourceMappingURL=initMockServer.js.map